To get started have python 3 installed and in cmd call
python main.py